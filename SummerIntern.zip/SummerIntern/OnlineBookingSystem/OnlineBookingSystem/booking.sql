CREATE DATABASE IF NOT EXISTS booking_system7;
USE booking_system7;

CREATE TABLE IF NOT EXISTS users1 (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(50) NOT NULL
);

CREATE TABLE bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    transportation_id INT UNIQUE,
    journey_details VARCHAR(255) NOT NULL,
    price DOUBLE NOT NULL,
    user_id INT,  -- Add user_id column here
    FOREIGN KEY (user_id) REFERENCES users(id)
);

select * from users1;
select * from bookings;
select * from users; 



#INSERT INTO users (id, username, password, email, role) VALUES (1, 'admin', 'admin123', 'admin@example.com', 'admin');
#-- CREATE TABLE IF NOT EXISTS bookings1 (
--     id INT AUTO_INCREMENT PRIMARY KEY,
--     user_id INT NOT NULL,
--     username VARCHAR(50) NOT NULL,
--     transportation_id INT NOT NULL,
--     journey_details VARCHAR(255) NOT NULL,
--     price DOUBLE NOT NULL,
--     FOREIGN KEY (user_id) REFERENCES users(id)
-- );

-- CREATE TABLE users (
--     id INT AUTO_INCREMENT PRIMARY KEY,
--     username VARCHAR(50) NOT NULL,
--     password VARCHAR(50) NOT NULL,
--     email VARCHAR(100) NOT NULL,
--     role VARCHAR(20) NOT NULL
-- );
package example;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ChartFrame extends JFrame {
    public ChartFrame() {
        setTitle("Booking Data Chart");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Create a bar chart based on booking data
        JFreeChart barChart = createBarChart();
        ChartPanel chartPanel = new ChartPanel(barChart);
        chartPanel.setPreferredSize(new Dimension(700, 500));
        setContentPane(chartPanel);

        setVisible(true);
    }

    public JFreeChart createBarChart() {
        // Retrieve booking data from the database
        CategoryDataset dataset = createDataset();

        // Create the chart
        JFreeChart barChart = ChartFactory.createBarChart(
                "Booking Data Overview",
                "Transportation ID",
                "Price",
                dataset,
                PlotOrientation.VERTICAL,
                true, true, false);

        return barChart;
    }

    private CategoryDataset createDataset() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/booking_system7", "root", "bhargav@143");
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT transportation_id, SUM(price) AS total_price FROM bookings GROUP BY transportation_id");

            while (rs.next()) {
                int transportationId = rs.getInt("transportation_id");
                double totalPrice = rs.getDouble("total_price");
                dataset.addValue(totalPrice, "Total Price", String.valueOf(transportationId));
            }

            con.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error retrieving data for chart", "Error", JOptionPane.ERROR_MESSAGE);
        }

        return dataset;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ChartFrame::new);
    }
}
package example;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.File;
import java.io.IOException;
import java.sql.*;

public class ReportFrame extends JFrame implements ActionListener {
    JButton generateReportButton, exportReportButton;
    JTable reportTable;
    JScrollPane scrollPane;

    public ReportFrame() {
        setTitle("Reports and Analytics");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel buttonPanel = new JPanel();
        generateReportButton = new JButton("Generate Report");
        generateReportButton.addActionListener(this);
        buttonPanel.add(generateReportButton);

        exportReportButton = new JButton("Export Report");
        exportReportButton.addActionListener(this);
        buttonPanel.add(exportReportButton);

        add(buttonPanel, BorderLayout.NORTH);

        reportTable = new JTable();
        scrollPane = new JScrollPane(reportTable);
        add(scrollPane, BorderLayout.CENTER);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == generateReportButton) {
            generateReport();
        } else if (e.getSource() == exportReportButton) {
            exportReport();
        }
    }

    private void generateReport() {
        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/booking_system7", "root", "bhargav@143");
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM bookings");

            DefaultTableModel tableModel = new DefaultTableModel(new String[]{"ID", "Transportation ID", "Journey Details", "Price"}, 0);
            while (rs.next()) {
                int id = rs.getInt("id");
                int transportationId = rs.getInt("transportation_id");
                String journeyDetails = rs.getString("journey_details");
                double price = rs.getDouble("price");
                tableModel.addRow(new Object[]{id, transportationId, journeyDetails, price});
            }

            reportTable.setModel(tableModel);

            con.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error generating report", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void exportReport() {
        JFileChooser fileChooser = new JFileChooser();
        int choice = fileChooser.showSaveDialog(this);
        if (choice == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            String filePath = file.getAbsolutePath();
            try {
                FileWriter fw = new FileWriter(filePath);
                for (int i = 0; i < reportTable.getRowCount(); i++) {
                    for (int j = 0; j < reportTable.getColumnCount(); j++) {
                        //fw.write(reportTable.getValueAt(i, j).toString() + ",");
                        fw.write(reportTable.getValueAt(i, j) + "\t");
                    }
                    fw.write("\n");
                }
                fw.close();
                JOptionPane.showMessageDialog(this, "Report exported successfully");
            } catch (IOException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error exporting report", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ReportFrame::new);
    }
}
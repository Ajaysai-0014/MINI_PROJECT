package example;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;

public class BookingFrame extends JFrame implements ActionListener {
    private JTextField transportationIdField;
	private JTextField journeyDetailsField;
	private JTextField priceField;
    private JButton bookButton;
	JButton crudButton;
	private JButton showChartButton;
	private JButton exportDataButton;

    String username;

    public BookingFrame(String username) {
        this.username = username;

        setTitle("Booking");
        setSize(1366, 1000);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        add(new JLabel("Transportation ID:"));
        setTransportationIdField(new JTextField(20));
        add(getTransportationIdField());

        add(new JLabel("Journey Details:"));
        setJourneyDetailsField(new JTextField(20));
        add(getJourneyDetailsField());

        add(new JLabel("Price:"));
        setPriceField(new JTextField(20));
        add(getPriceField());

        setBookButton(new JButton("Book"));
        getBookButton().addActionListener(this);
        add(getBookButton());

        crudButton = new JButton("Manage Bookings");
        crudButton.addActionListener(this);
        add(crudButton);

        setShowChartButton(new JButton("Show Chart"));
        getShowChartButton().addActionListener(this);
        add(getShowChartButton());

        setExportDataButton(new JButton("Export Data"));
        getExportDataButton().addActionListener(this);
        add(getExportDataButton());

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == getBookButton()) {
            bookTransportation();
        } else if (e.getSource() == crudButton) {
            new CRUDFrame();
        } else if (e.getSource() == getShowChartButton()) {
            showChart();
        } else if (e.getSource() == getExportDataButton()) {
            exportData();
        }
    }

    private void bookTransportation() {
        String transportationIdText = getTransportationIdField().getText();
        String journeyDetails = getJourneyDetailsField().getText();
        String priceText = getPriceField().getText();

        if (transportationIdText.isEmpty() || journeyDetails.isEmpty() || priceText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int transportationId;
        double price;
        try {
            transportationId = Integer.parseInt(transportationIdText);
            price = Double.parseDouble(priceText);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid input format", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/booking_system7", "root", "bhargav@143");
            PreparedStatement pst = con.prepareStatement("INSERT INTO bookings (user_id, transportation_id, journey_details, price) VALUES ((SELECT id FROM users1 WHERE username = ?), ?, ?, ?)");
            pst.setString(1, username);
            pst.setInt(2, transportationId);
            pst.setString(3, journeyDetails);
            pst.setDouble(4, price);
            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "Booking successful");
            con.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error processing booking", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void showChart() {
        new ChartFrame();
    }

    private void exportData() {
        JFileChooser fileChooser = new JFileChooser();
        int choice = fileChooser.showSaveDialog(this);
        if (choice == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            String filePath = file.getAbsolutePath();
            try {
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/booking_system7", "root", "bhargav@143");
                Statement stmt = con.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT * FROM bookings");

                StringBuilder data = new StringBuilder();
                while (rs.next()) {
                    int id = rs.getInt("id");
                    int transportationId = rs.getInt("transportation_id");
                    String journeyDetails = rs.getString("journey_details");
                    double price = rs.getDouble("price");
                    data.append(id).append("\t").append(transportationId).append("\t").append(journeyDetails).append("\t").append(price).append("\n");
                }

                FileWriter fw = new FileWriter(filePath);
                fw.write(data.toString());
                fw.close();

                JOptionPane.showMessageDialog(this, "Data exported successfully");
                con.close();
            } catch (IOException | SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error exporting data", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new BookingFrame("admin"));
    }

	public JButton getShowChartButton() {
		return showChartButton;
	}

	public void setShowChartButton(JButton showChartButton) {
		this.showChartButton = showChartButton;
	}

	public JButton getExportDataButton() {
		return exportDataButton;
	}

	public void setExportDataButton(JButton exportDataButton) {
		this.exportDataButton = exportDataButton;
	}

	public JTextField getTransportationIdField() {
		return transportationIdField;
	}

	public void setTransportationIdField(JTextField transportationIdField) {
		this.transportationIdField = transportationIdField;
	}

	public JTextField getJourneyDetailsField() {
		return journeyDetailsField;
	}

	public void setJourneyDetailsField(JTextField journeyDetailsField) {
		this.journeyDetailsField = journeyDetailsField;
	}

	public JTextField getPriceField() {
		return priceField;
	}

	public void setPriceField(JTextField priceField) {
		this.priceField = priceField;
	}

	public JButton getBookButton() {
		return bookButton;
	}

	public void setBookButton(JButton bookButton) {
		this.bookButton = bookButton;
	}
}
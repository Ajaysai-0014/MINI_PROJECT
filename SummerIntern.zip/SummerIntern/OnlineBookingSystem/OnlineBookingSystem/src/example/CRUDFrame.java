package example;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class CRUDFrame extends JFrame implements ActionListener {
    JTextField bookingIdField, transportationIdField, journeyDetailsField, priceField;
    JButton addButton, updateButton, deleteButton, viewButton;
    JTable bookingsTable;
    JScrollPane scrollPane;

    public CRUDFrame() {
        setTitle("Manage Bookings");
        setSize(1366,1000);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new FlowLayout());

        add(new JLabel(" ID:"));
        bookingIdField = new JTextField(5);
        add(bookingIdField);

        add(new JLabel("Transportation ID:"));
        transportationIdField = new JTextField(10);
        add(transportationIdField);

        add(new JLabel("Journey Details:"));
        journeyDetailsField = new JTextField(15);
        add(journeyDetailsField);

        add(new JLabel("Price:"));
        priceField = new JTextField(10);
        add(priceField);

//        addButton = new JButton("Add");
//        addButton.addActionListener(this);
//        add(addButton);

        updateButton = new JButton("Update");
        updateButton.addActionListener(this);
        add(updateButton);

        deleteButton = new JButton("Delete");
        deleteButton.addActionListener(this);
        add(deleteButton);

        viewButton = new JButton("View All");
        viewButton.addActionListener(this);
        add(viewButton);

        bookingsTable = new JTable();
        scrollPane = new JScrollPane(bookingsTable);
        scrollPane.setPreferredSize(new Dimension(550, 200));
        add(scrollPane);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
//        if (e.getSource() == addButton) {
//            addBooking();
//        } 
        if (e.getSource() == updateButton) {
            updateBooking();
        } else if (e.getSource() == deleteButton) {
            deleteBooking();
        } else if (e.getSource() == viewButton) {
            viewAllBookings();
        }
    }

//    private void addBooking() {
//        String transportationIdText = transportationIdField.getText();
//        String journeyDetails = journeyDetailsField.getText();
//        String priceText = priceField.getText();
//
//        if (transportationIdText.isEmpty() || journeyDetails.isEmpty() || priceText.isEmpty()) {
//            JOptionPane.showMessageDialog(this, "Please fill all fields", "Error", JOptionPane.ERROR_MESSAGE);
//            return;
//        }
//
//        int transportationId;
//        double price;
//        try {
//            transportationId = Integer.parseInt(transportationIdText);
//            price = Double.parseDouble(priceText);
//        } catch (NumberFormatException ex) {
//            JOptionPane.showMessageDialog(this, "Invalid input format", "Error", JOptionPane.ERROR_MESSAGE);
//            return;
//        }
//
//        try {
//            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/booking_system7", "root", "bhargav@143");
//            PreparedStatement pst = con.prepareStatement("INSERT INTO bookings (transportation_id, journey_details, price) VALUES (?, ?, ?)");
//            pst.setInt(1, transportationId);
//            pst.setString(2, journeyDetails);
//            pst.setDouble(3, price);
//            pst.executeUpdate();
//            JOptionPane.showMessageDialog(this, "Booking added successfully");
//            con.close();
//            viewAllBookings();
//        } catch (SQLException ex) {
//            ex.printStackTrace();
//            JOptionPane.showMessageDialog(this, "Error adding booking", "Error", JOptionPane.ERROR_MESSAGE);
//        }
//    }

    private void updateBooking() {
        String bookingIdText = bookingIdField.getText();
        String transportationIdText = transportationIdField.getText();
        String journeyDetails = journeyDetailsField.getText();
        String priceText = priceField.getText();

        if (bookingIdText.isEmpty() || transportationIdText.isEmpty() || journeyDetails.isEmpty() || priceText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int bookingId, transportationId;
        double price;
        try {
            bookingId = Integer.parseInt(bookingIdText);
            transportationId = Integer.parseInt(transportationIdText);
            price = Double.parseDouble(priceText);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid input format", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/booking_system7", "root", "bhargav@143");
            // Check if the booking exists
            PreparedStatement checkPst = con.prepareStatement("SELECT * FROM bookings WHERE id = ?");
            checkPst.setInt(1, bookingId);
            ResultSet rs = checkPst.executeQuery();

            if (!rs.next()) {
                JOptionPane.showMessageDialog(this, "Booking ID not found", "Error", JOptionPane.ERROR_MESSAGE);
                con.close();
                return;
            }

            PreparedStatement pst = con.prepareStatement("UPDATE bookings SET transportation_id = ?, journey_details = ?, price = ? WHERE id = ?");
            pst.setInt(1, transportationId);
            pst.setString(2, journeyDetails);
            pst.setDouble(3, price);
            pst.setInt(4, bookingId);
            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "Booking updated successfully");
            con.close();
            viewAllBookings();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error updating booking", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteBooking() {
        String bookingIdText = bookingIdField.getText();

        if (bookingIdText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill the Booking ID field", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int bookingId;
        try {
            bookingId = Integer.parseInt(bookingIdText);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid Booking ID format", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/booking_system7", "root", "bhargav@143");
            // Check if the booking exists
            PreparedStatement checkPst = con.prepareStatement("SELECT * FROM bookings WHERE id = ?");
            checkPst.setInt(1, bookingId);
            ResultSet rs = checkPst.executeQuery();

            if (!rs.next()) {
                JOptionPane.showMessageDialog(this, "Booking ID not found", "Error", JOptionPane.ERROR_MESSAGE);
                con.close();
                return;
            }

            PreparedStatement pst = con.prepareStatement("DELETE FROM bookings WHERE id = ?");
            pst.setInt(1, bookingId);
            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "Booking deleted successfully");
            con.close();
            viewAllBookings();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error deleting booking", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void viewAllBookings() {
        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/booking_system7", "root", "bhargav@143");
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM bookings");

            // Create table model from result set
            DefaultTableModel tableModel = new DefaultTableModel(new String[]{"ID", "Transportation ID", "Journey Details", "Price"}, 0);
            while (rs.next()) {
                int id = rs.getInt("id");
                int transportationId = rs.getInt("transportation_id");
                String journeyDetails = rs.getString("journey_details");
                double price = rs.getDouble("price");
                tableModel.addRow(new Object[]{id, transportationId, journeyDetails, price});
            }
            bookingsTable.setModel(tableModel);

            con.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error retrieving bookings", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(CRUDFrame::new);
    }
}
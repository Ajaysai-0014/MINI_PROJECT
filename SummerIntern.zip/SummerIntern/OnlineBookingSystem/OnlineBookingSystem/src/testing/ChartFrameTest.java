package testing;



import static org.junit.Assert.*;
import org.junit.*;

import example.ChartFrame;

public class ChartFrameTest {

    @Test
    public void testCreateBarChart() {
        ChartFrame chartFrame = new ChartFrame();
        assertNotNull(chartFrame.createBarChart());
    }

    // Additional tests can be added to validate different aspects of ChartFrame
}


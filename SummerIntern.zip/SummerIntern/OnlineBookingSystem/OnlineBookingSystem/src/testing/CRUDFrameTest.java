package testing;



import static org.junit.Assert.*;
import org.junit.*;

import example.CRUDFrame;

public class CRUDFrameTest {

    @Test
    public void testUpdateBooking() {
        CRUDFrame crudFrame = new CRUDFrame();
        // Perform UI interactions or simulate user actions to test update functionality
    }

    @Test
    public void testDeleteBooking() {
        CRUDFrame crudFrame = new CRUDFrame();
        // Perform UI interactions or simulate user actions to test delete functionality
    }

    // Additional tests can be added for addBooking and viewAllBookings methods
}


package testing;



import static org.junit.Assert.*;
import org.junit.*;

import example.BookingFrame;

import java.awt.*;
import java.io.*;
import java.sql.*;

import javax.swing.JFileChooser;

public class BookingFrameTest {

    

    @Test
    public void testShowChart() {
        BookingFrame bookingFrame = new BookingFrame("testuser");
        bookingFrame.getShowChartButton().doClick();
        // Assertion to be added based on chart display verification
    }

    @Test
    public void testExportData() {
        BookingFrame bookingFrame = new BookingFrame("testuser");

        JFileChooserMock fileChooser = new JFileChooserMock();
        fileChooser.setApproveReturnValue(JFileChooser.APPROVE_OPTION);
        bookingFrame.getExportDataButton().doClick();

        // Assertion to check if data export was successful
        // Verify the exported file content or existence
    }

    // Mock class to simulate JFileChooser selection
    private static class JFileChooserMock extends JFileChooser {
        private int approveReturnValue;

        public void setApproveReturnValue(int approveReturnValue) {
            this.approveReturnValue = approveReturnValue;
        }

        @Override
        public int showSaveDialog(Component parent) {
            return approveReturnValue;
        }

        @Override
        public File getSelectedFile() {
            return new File("test_export.csv"); // Return a dummy file for testing
        }
    }
}

